﻿using System;
using System.Collections.Generic;
using System.Text;
using Vixen;
using System.Windows.Forms;
using System.Xml;

namespace AddInTutorial
{
    public class AddIn:IAddIn
    {
        private XmlNode m_datanode;

        public bool Execute(EventSequence sequence)
        {
            if (sequence == null)
            {
                throw new Exception("This AddIn requires a sequence to be open!");
            }

            if (sequence.Audio == null)
            {
                throw new Exception("This AddIn requires attached audio");
            }

            AddinDialog dialog = new AddinDialog(sequence);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                for (int column = 0; column < sequence.TotalEventPeriods; column++)
                {
                    sequence.EventValues[0, column] = (byte)125;
                }
            }
            dialog.Close();
            return true;

        }

        public LoadableDataLocation DataLocationPreference
        {
            get { return LoadableDataLocation.Sequence; }
        }

        public void Loading(XmlNode dataNode)
        {
            this.m_datanode=dataNode;
        }

        public void Unloading()
        {
        }

        public string Author
        {
            get { return "ctmal"; }
        }

        public string Description
        {
            get { return "AddIn Tutorial"; }
        }

        public string Name
        {
            get { return "AddIn Tutorial"; }
        }
    }
}
