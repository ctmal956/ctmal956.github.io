﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Vixen;

namespace AddInTutorial
{
    public partial class AddinDialog : Form
    {
        private EventSequence m_sequence;
        
        public AddinDialog(EventSequence Sequence)
        {
            this.m_sequence = Sequence;
            InitializeComponent();
            lbOutput.Items.Add("Sequence: " + this.m_sequence.Name);
            lbOutput.Items.Add("Audio: " + this.m_sequence.Audio.Name);
        }
    }
}
