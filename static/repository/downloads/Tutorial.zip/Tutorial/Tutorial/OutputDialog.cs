﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Vixen;

namespace Tutorial
{
    public partial class OutputDialog : OutputPlugInUIBase
    {
        public OutputDialog()
        {
            InitializeComponent();
        }

        public byte VixenEvent
        {
            set{lbOutput.Items.Add(value.ToString());}
        }
    }
}
