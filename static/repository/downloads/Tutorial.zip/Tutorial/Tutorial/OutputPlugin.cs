﻿using System;
using System.Collections.Generic;
using System.Text;
using Vixen;
using System.Windows.Forms;
using System.Xml;
using System.Reflection;

namespace Tutorial
{
    public class OutputPlugin:IEventDrivenOutputPlugIn
    {
        private SetupData m_setupdata;
        private XmlNode m_setupnode;
        private List<Channel> m_channels;
        private int m_selectedIndex;
        private OutputDialog m_outputDialog;
        
        public void Event(byte[] channelValues)
        {
            m_outputDialog.VixenEvent = channelValues[m_selectedIndex];
        }

        public void Initialize(IExecutable executableObject, SetupData setupData, XmlNode setupNode)
        {
            this.m_setupdata = setupData;
            this.m_setupnode = setupNode;
            this.m_channels = executableObject.Channels;

            if (this.m_setupnode.SelectSingleNode("Settings") == null)
            {
                Xml.GetNodeAlways(this.m_setupnode, "Settings");
                this.m_selectedIndex = 0;
            }
            else
            {
                XmlNode node = this.m_setupnode.SelectSingleNode("Settings/ChannelIndex");
                this.m_selectedIndex = Convert.ToInt16(node.InnerText);
            }
        }

        public HardwareMap[] HardwareMap
        {
            get { return new HardwareMap[0]; }
        }

        public void Setup()
        {
            int startchannel = Convert.ToInt16(this.m_setupnode.Attributes["from"].Value) - 1;
            
            SetupDialog dialog = new SetupDialog(this.m_channels,startchannel);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                int selection = dialog.SelectedChannel;
                XmlNode contextNode = this.m_setupnode.SelectSingleNode("Settings");
                contextNode.RemoveAll();
                XmlNode newnode = Xml.SetNewValue(contextNode, "ChannelIndex", selection.ToString());
                Xml.SetAttribute(newnode, "Attribute", "value");
            }
            dialog.Close();
        }

        public void Shutdown()
        {
            this.m_outputDialog.Close();
        }

        public List<Form> Startup()
        {
            //this.m_outputDialog = new OutputDialog();
            //this.m_outputDialog.Show();
            ISystem system = (ISystem)Interfaces.Available["ISystem"];
            ConstructorInfo constructor = typeof(OutputDialog).GetConstructor(System.Type.EmptyTypes);
            this.m_outputDialog = (OutputDialog)system.InstantiateForm(constructor, System.Type.EmptyTypes);
            return new List<Form>();
        }

        public string Author
        {
            get { return "ctmal"; }
        }

        public string Description
        {
            get { return "Output Plugin Tutorial"; }
        }

        public string Name
        {
            get { return "Tutorial"; }
        }

        public override string ToString()
        {
            return this.Name;
        }
    }
}
