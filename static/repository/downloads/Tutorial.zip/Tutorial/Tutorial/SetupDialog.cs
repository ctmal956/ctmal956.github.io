﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Vixen;

namespace Tutorial
{
    public partial class SetupDialog : Form
    {
        public SetupDialog(List<Channel> channels,int startChannel)
        {
            InitializeComponent();
            foreach (Channel ch in channels)
            {
                if (ch.OutputChannel >= startChannel)
                {
                    cmboSelectedChannel.Items.Add(ch.Name);
                }
            }
            cmboSelectedChannel.SelectedIndex = 0;
        }

        public int SelectedChannel
        {
            get { return cmboSelectedChannel.SelectedIndex; }
        }
    }
}
